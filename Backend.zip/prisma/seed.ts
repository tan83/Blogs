import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { AUTHOR, INITIAL_POSTS } from "../../frontend/src/data/posts.ts";

const prisma = new PrismaClient();

async function main() {
  const author =
    (await prisma.author.findFirst({ where: { name: AUTHOR.name } })) ??
    (await prisma.author.create({ data: AUTHOR }));

  await prisma.author.update({ where: { id: author.id }, data: AUTHOR });

  for (const post of INITIAL_POSTS) {
    const publishedAt = new Date(`${post.publishedAt}T00:00:00.000Z`);
    const data = {
      title: post.title,
      excerpt: post.excerpt,
      content: post.content,
      category: post.category,
      tags: post.tags,
      coverImage: post.coverImage,
      publishedAt,
      readTime: post.readTime,
      status: post.status,
      views: post.views,
      featured: post.featured ?? false,
      authorId: author.id,
    };

    await prisma.post.upsert({
      where: { slug: post.slug },
      update: data,
      create: { slug: post.slug, ...data },
    });
  }

  const password = await bcrypt.hash("pass1234", 10);
  await prisma.admin.upsert({
    where: { email: "admin@blog.dev" },
    update: { password },
    create: { email: "admin@blog.dev", password },
  });

  console.log("Seed completed: author, posts and admin user are ready.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());