import { RouterProvider } from "react-router";
import { ThemeProvider } from "@/context/ThemeContext";
import { AuthProvider } from "@/context/AuthContext";
import { PostsProvider } from "@/context/PostsContext";
import { router } from "./routes";

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <PostsProvider>
          <RouterProvider router={router} />
        </PostsProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
